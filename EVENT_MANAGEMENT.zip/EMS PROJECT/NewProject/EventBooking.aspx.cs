﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;

namespace NewProject
{
    public partial class EventBooking : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand com;
        SqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_id"] == null)
            {
                Response.Redirect("~/Admin/AdminLoginPage.aspx");
            }
            if (!Page.IsPostBack)
            {
                con = new SqlConnection("Data Source=LAPTOP-9DG34U7Q\\SQLEXPRESS;Initial Catalog=Event_Management_System;Integrated Security=True");
                con.Open();
                com = new SqlCommand("select Customer_id from tblCustomer_Registration", con);

                dr = com.ExecuteReader();
                while (dr.Read())
                {
                    DDLCustID.Items.Add(dr[0].ToString());
                }
                dr.Close();
                com.Dispose();
                con.Close();
            }
        }

        protected void EventCustomName_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (args.Value == "")
            {
                args.IsValid = false;
            }
            else
            {
                string expression = "^[A-Za-z ]{1,20}$";
                Regex reg = new Regex(expression);
                if (reg.IsMatch(args.Value))
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;
                }
            }
        }

        protected void EventDateEnd_SelectionChanged(object sender, EventArgs e)
        {
            //EventLblStartDate.Text = EventDateStart.SelectedDate.ToString("yyyy-MM-dd");
            //EventLblEndDate.Text = EventDateEnd.SelectedDate.ToString("yyyy-MM-dd");

            DateTime st = Convert.ToDateTime(EventDateStart.SelectedDate.ToString("yyyy-MM-dd"));
            DateTime et = Convert.ToDateTime(EventDateEnd.SelectedDate.ToString("yyyy-MM-dd"));
            DateTime current = DateTime.Today;

            if (et < st)
            {
                Response.Write("<script>alert('Please choose a valid event end date')</script>");
                EventLblStartDate.Text =" ";
                EventLblEndDate.Text = " ";
                                       

            }
            else if (st < current)
            {
                Response.Write("<script>alert('Please choose a valid event end date')</script>");
            }
            else if (et < current)
            {
                Response.Write("<script>alert('Please choose a valid event end date')</script>");
            }
            else
            {
                EventLblStartDate.Text = EventDateStart.SelectedDate.ToString("yyyy-MM-dd");
                EventLblEndDate.Text = EventDateEnd.SelectedDate.ToString("yyyy-MM-dd");
            }

            //datetime st = convert.todatetime(eventlblstartdate.text);
            //datetime et = convert.todatetime(eventlblenddate.text);

            //if (st > et)
            //{

            //    eventlblerror.text = "event start date cannot be greater than end date";

            //}
            //else
            //{
            //    eventlblerror.text = string.empty;
            //    eventlblstartdate.text = eventdatestart.selecteddate.tolongdatestring();
            //    eventlblenddate.text = eventdateend.selecteddate.tolongdatestring();
            //}

        }
        public void Reset()
        {
            DDLCustID.SelectedItem.Text = string.Empty;
            EventTxtName.Text = string.Empty;
            EventLblStartDate.Text = string.Empty;
            EventLblEndDate.Text = string.Empty;
            EventDDLType.SelectedItem.Text = string.Empty;
            EventDDLVenue.SelectedItem.Text = string.Empty;
            EventTxtStartTime.Text = string.Empty;
            EventTxtEndTime.Text = string.Empty;
            EventTxtBudget.Text = string.Empty;
        }

        protected void EventBtnReset_Click(object sender, EventArgs e)
        {
            Reset();
        }

        protected void EventBtnRegister_Click(object sender, EventArgs e)
        {
            try
            {       
   
            if (Page.IsValid)
            {
                con = new SqlConnection("Data Source=PC429615;Initial Catalog=Event_Management_System;Integrated Security=True");
                con.Open();
                DateTime Evedatetime;
                //DateTime start = Convert.ToDateTime(EventLblStartDate.Text.ToString());
                //DateTime end = Convert.ToDateTime(EventLblEndDate.Text.ToString());           
                //DateTime st_time = Convert.ToDateTime(EventTxtStartTime.Text);
                //DateTime en_time = Convert.ToDateTime(EventTxtEndTime.Text);
                //DateTime et = new DateTime();
                //et = Convert.ToDateTime(lblEXPdate.Text);
                //cmd.Parameters.Add("@Expiry_date", SqlDbType.Date).Value = et.ToLongDateString().Trim();

                string st, en;
                st = EventTxtStartTime.Text;
                en = EventTxtEndTime.Text;
                DateTime start = new DateTime();
                start = Convert.ToDateTime(EventLblStartDate.Text);
                DateTime end = new DateTime();
                end = Convert.ToDateTime(EventLblEndDate.Text);
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "SPtblEventRegistration";
                cmd.Parameters.Add("@Customer_id", SqlDbType.VarChar).Value = DDLCustID.SelectedItem.Text;
                cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = EventTxtName.Text.Trim();
                //cmd.Parameters.Add("@Start_date", SqlDbType.DateTime).Value = Convert.ToDateTime((EventLblStartDate.Text + " " + EventTxtStartTime.Text).ToString());
                //cmd.Parameters.Add("@End_date", SqlDbType.DateTime).Value = Convert.ToDateTime((EventTxtEndTime.Text + " " + EventLblEndDate.Text).ToString()); 
                Evedatetime = DateTime.ParseExact(EventLblStartDate.Text + " " + EventTxtStartTime.Text,"yyyy-MM-dd HH:mm",CultureInfo.InvariantCulture);
                cmd.Parameters.Add("@Start_date", SqlDbType.DateTime).Value = Evedatetime;
                Evedatetime = DateTime.ParseExact(EventLblEndDate.Text + " " + EventTxtEndTime.Text,"yyyy-MM-dd HH:mm",CultureInfo.InvariantCulture);
                cmd.Parameters.Add("@End_date", SqlDbType.DateTime).Value = Evedatetime;
              //start.ToLongDateString("yyyy-MM-dd").Trim()+" "+st.ToString();
                //  cmd.Parameters.Add("@End_date", SqlDbType.Date).Value = end.ToLongDateString().Trim()+" "+en.ToString();
                cmd.Parameters.Add("@Type", SqlDbType.VarChar).Value = EventDDLType.SelectedItem.Text;
                cmd.Parameters.Add("@Venue_Name", SqlDbType.VarChar).Value = EventDDLVenue.SelectedItem.Text;
                cmd.Parameters.Add("@Start_time", SqlDbType.VarChar).Value = EventTxtStartTime.Text.Trim();
                cmd.Parameters.Add("@End_time", SqlDbType.VarChar).Value = EventTxtEndTime.Text.Trim();
                cmd.Parameters.Add("@Budget", SqlDbType.Int).Value = Convert.ToInt32(EventTxtBudget.Text.Trim());
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
                Response.Write("<script>alert('Event has been registered successfully')</script>");
                Reset();
            }
            }
            catch (Exception f)
            {

                Response.Write("<script>alert('Invalid Data or the format is not supported')</script>");
            }
        }

        protected void DDLCustID_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void CustomStartTimeValidate_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (args.Value == "")
            {
                args.IsValid = false;
            }
            else
            {
                DateTime dd;

                if (DateTime.TryParseExact(EventTxtStartTime.Text, "HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out dd))
                {


                    args.IsValid = true;

                }

                else
                {
                    args.IsValid = false;
                }




                //string expression = @"^(?:[01][0-9]|2[0-3]):[0-5][0-9]$";
                //Regex reg = new Regex(expression);
                //if (reg.IsMatch(args.Value))
                //{
                //    args.IsValid = true;
                //}
                //else
                //{
                //    args.IsValid = false;
                //}
            }
        }



        protected void EventLinkShow_Click(object sender, EventArgs e)
        {
            GridView1.Visible = true;
            btnClose.Visible = true;
        }

        protected void btnClose_Click(object sender, EventArgs e)
        {
            GridView1.Visible = false;
            btnClose.Visible = false;
        }

        protected void CustomEndTimeValidator_ServerValidate(object source, ServerValidateEventArgs args)
        {

            if (args.Value == "")
            {
                args.IsValid = false;
            }
            else
            {
                DateTime dd;

                if (DateTime.TryParseExact(EventTxtEndTime.Text, "HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out dd))
                {


                    args.IsValid = true;

                }

                else
                {
                    args.IsValid = false;
                }







                //if (args.Value == "")
                //{
                //    args.IsValid = false;
                //}
                //else
                //{
                //    string expression = @"^(?:[01][0-9]|2[0-3]):[0-5][0-9]$";
                //    Regex reg = new Regex(expression);
                //    if (reg.IsMatch(args.Value))
                //    {
                //        args.IsValid = true;
                //    }
                //    else
                //    {
                //        args.IsValid = false;
                //    }
                //}
            }
        }
    }
}