﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.SqlClient;

namespace NewProject
{
    public partial class VendorManagement : System.Web.UI.Page
    {
        public void Reset()
        {
            VendortxtName.Text = string.Empty;
            VendortxtAddress.Text = string.Empty;
            VendortxtCity.Text = string.Empty;
            VendortxtEmail.Text = string.Empty;
            VendortxtContactNum.Text = string.Empty;

        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void VendorCustomValidatorName_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (args.Value == "")
            {
                args.IsValid = false;
            }
            else
            {
                string expression = "^[A-Za-z ]{1,20}$";
                Regex reg = new Regex(expression);
                if (reg.IsMatch(args.Value))
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;
                }
            }
        }

        protected void VendorCustomValidatorAddress_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (args.Value == "")
            {
                args.IsValid = false;
            }
            else
            {
                string expression = "^[A-Za-z0-9 ]{4,200}$";
                Regex reg = new Regex(expression);
                if (reg.IsMatch(args.Value))
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;
                }
            }
        }

        protected void VendorCustomValidatorCity_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (args.Value == "")
            {
                args.IsValid = false;
            }
            else
            {
                string expression = "^[A-Za-z]{4,20}$";
                Regex reg = new Regex(expression);
                if (reg.IsMatch(args.Value))
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;
                }
            }
        }

        protected void VendorCustomValidatorEmail_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (args.Value == "")
            {
                args.IsValid = false;
            }
            else
            {
                string expression = @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";
                Regex reg = new Regex(expression);
                if (reg.IsMatch(args.Value))
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;
                }
            }
        }

        protected void VendorCustomValidatorContact_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (args.Value == "")
            {
                args.IsValid = false;
            }
            else
            {
                string expression = "^[0-9]{10}$";
                Regex reg = new Regex(expression);
                if (reg.IsMatch(args.Value))
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;
                }
            }
        }
        //public void Reset()
        //{
        //    VendortxtName.Text = string.Empty;
        //    VendortxtAddress.Text = string.Empty;
        //    VendortxtCity.Text = string.Empty;
        //    VendortxtEmail.Text = string.Empty;
        //    VendortxtContactNum.Text = string.Empty;
        //}
        //protected void VendorbtnReset_Click(object sender, EventArgs e)
        //{
        //    Reset();
        //}

        //protected void VendorbtnRegister_Click(object sender, EventArgs e)
        //{
        //    Response.Write("<script>alert('Registration Successfull')</script>");
        //    Reset();
        //}

        protected void VendorbtnReset_Click1(object sender, EventArgs e)
        {
            Reset();
        }

        protected void VendorbtnAddFacility_Click(object sender, EventArgs e)
        {

        }

        protected void FormView1_PageIndexChanging(object sender, FormViewPageEventArgs e)
        {

        }

        protected void VendorbtnAddFacility_Click1(object sender, EventArgs e)
        {
            Response.Redirect("~/FacilityScreenPopUp.aspx");
        }

       

        protected void VendorbtnRegister_Click1(object sender, EventArgs e)
        {
            try
            {

           
            if (Page.IsValid)
            {
                SqlCommand cmd;
                SqlConnection con;
                con = new SqlConnection("Data Source=PC429615;Initial Catalog=Event_Management_System;Integrated Security=True");
                con.Open();
                cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "SPtblVendor_Screen";
                cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = VendortxtName.Text;
                cmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = VendortxtAddress.Text;
                cmd.Parameters.Add("@City", SqlDbType.VarChar).Value = VendortxtCity.Text;
                cmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = VendortxtEmail.Text;
                cmd.Parameters.Add("@Contact_no", SqlDbType.VarChar).Value = VendortxtContactNum.Text;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
                Response.Write("<script>alert('Vendor Details Added Successfully')</script>");
                Reset();
            }
            }
            catch (Exception x)
            {

                Response.Write("<script>alert('Invalid Input or format not supported')</script>");
            }
        }
    }
}