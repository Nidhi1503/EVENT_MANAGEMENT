﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.SqlClient;

namespace NewProject
{
    public partial class FacilityScreenPopUp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_id"] == null)
            {
                Response.Redirect("~/Admin/AdminLoginPage.aspx");
            }
        }

        protected void TxtPopUPFacilityDesc_TextChanged(object sender, EventArgs e)
        {

        }

        protected void FacilityPopUPDescValidator_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (args.Value == "")
            {
                args.IsValid = false;
            }
            else
            {
                string expression = "^[A-Za-z ]{1,200}$";
                Regex reg = new Regex(expression);
                if (reg.IsMatch(args.Value))
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;
                }
            }
        }

        protected void FacilityPopUPCostValidator_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (args.Value == "")
            {
                args.IsValid = false;
            }
            else
            {
                string expression = "^[0-9]{1,10}$";
                Regex reg = new Regex(expression);
                if (reg.IsMatch(args.Value))
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;
                }
            }
        }

        public void Reset()
        {
            TxtPopUPFacilityDesc.Text = string.Empty;
            TxtPopUPFacilityCost.Text = string.Empty;
        }

        protected void btnFacilityAddMore_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/FacilityScreenPopUp.aspx");
        }

        protected void btnFacilityReset_Click(object sender, EventArgs e)
        {
            Reset();
        }

        protected void btnFacilityPopUP_Click(object sender, EventArgs e)
        {
            try
            {

            
            if (Page.IsValid)
            {
                SqlCommand cmd;
                SqlConnection con;
                con = new SqlConnection("Data Source=PC429615;Initial Catalog=Event_Management_System;Integrated Security=True");
                con.Open();
                cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "SPtblFacility_Screen";
                cmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = TxtPopUPFacilityDesc.Text;
                cmd.Parameters.Add("@Cost", SqlDbType.Int).Value = int.Parse(TxtPopUPFacilityCost.Text);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
                Response.Write("<script>alert('Facility Details Added Successfully')</script>");
            }
            }
            catch (Exception ex)
            {

                Response.Write("<script>alert('Invalid Input or the format was not supported')</script>");
            }
        }
    }
}