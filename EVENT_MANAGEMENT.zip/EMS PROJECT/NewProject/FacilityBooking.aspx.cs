﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.SqlClient;

namespace NewProject
{
    public partial class FacilityBooking : System.Web.UI.Page
    {


        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_id"] == null)
            {
                Response.Redirect("~/Admin/AdminLoginPage.aspx");
            }
        }

        protected void FacilityCustomValidatorCost_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (args.Value == "")
            {
                args.IsValid = false;
            }
            else
            {
                string expression = "^[0-9]{1,10}$";
                Regex reg = new Regex(expression);
                if (reg.IsMatch(args.Value))
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;
                }
            }


        }

        protected void FacilityCustomValidatorQty_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (args.Value == "")
            {
                args.IsValid = false;
            }
            else
            {
                string expression = "^[0-9]{1,10}$";
                Regex reg = new Regex(expression);
                if (reg.IsMatch(args.Value))
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;

                }

            }
        }

        public void Reset()
        {
            //DDLFacilityCustID.SelectedItem.Text = string.Empty;
            //DDLFacilityEventID.SelectedItem.Text = string.Empty;
            //FacilityDDLDes.SelectedItem.Text = string.Empty;
            //FacilityDDLVenId.SelectedItem.Text = string.Empty;
            Facilitytxtcost.Text = string.Empty;
            FacilitytxtQty.Text = string.Empty;
            foreach (ListItem item in CheckBoxFacility.Items)
            {
                //check anything out here
                if (item.Selected)
                    item.Selected = false;
            }
            
        }

        //protected void Facilitybtnreset_Click(object sender, EventArgs e)
        //{
        //    Reset();
        //}

        protected void FacilitybtnSub_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('Facility Booking Has Been Successfull')</script>");
            Reset();
        }

        protected void FacilitybtnSub_Click1(object sender, EventArgs e)
        {
            try
            {

            
            string s = "";
            if (Page.IsValid)
            {
                SqlCommand cmd;
                SqlConnection con;
                con = new SqlConnection("Data Source=PC429615;Initial Catalog=Event_Management_System;Integrated Security=True");
                con.Open();
                cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "SPtblFacility_Booking";
                cmd.Parameters.Add("@Customer_Id", SqlDbType.VarChar).Value = DDLFacilityCustID.SelectedItem.Text;
                cmd.Parameters.Add("@Event_Id", SqlDbType.VarChar).Value = DDLFacilityEventID.SelectedItem.Text;
                cmd.Parameters.Add("@Facility_desc", SqlDbType.VarChar).Value = FacilityDDLDes.SelectedItem.Text;
                cmd.Parameters.Add("@Vendor_ID", SqlDbType.Int).Value = int.Parse(FacilityDDLVenId.SelectedItem.Text);
                cmd.Parameters.Add("@Cost", SqlDbType.Int).Value = int.Parse(Facilitytxtcost.Text);
                cmd.Parameters.Add("@Quantity", SqlDbType.Int).Value = int.Parse(FacilitytxtQty.Text);

                for (int i = 0; i < CheckBoxFacility.Items.Count; i++)
                {
                    if (CheckBoxFacility.Items[i].Selected)
                    {
                        s += CheckBoxFacility.Items[i].Value + ", ";
                    }
                }
                s = s.TrimEnd(',', ' ');
                cmd.Parameters.Add("@Add_More_Facility", SqlDbType.VarChar).Value = s;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
                Response.Write("<script>alert('Facility has been successfully registered')</script>");
                Reset();
            }
            }
            catch (Exception ex)
            {

                Response.Write("<script>alert('Invalid data or format not supported')</script>");
            }
        }

        protected void FacilityDDLVenId_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlCommand cmd;
            SqlConnection con;
            con = new SqlConnection("Data Source=PC429615;Initial Catalog=Event_Management_System;Integrated Security=True");
            con.Open();



        }

        protected void Facilitybtnreset_Click1(object sender, EventArgs e)
        {
            Reset();
        }
    }
}
