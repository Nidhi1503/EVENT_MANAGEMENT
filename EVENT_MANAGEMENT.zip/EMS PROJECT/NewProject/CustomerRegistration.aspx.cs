﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.SqlClient;

namespace NewProject
{
    public partial class CustomerRegistration1 : System.Web.UI.Page
    {

        public void Reset()
        {

            txtCust_Name.Text = " ";
            txtCust_contact.Text = string.Empty;
            txtCustAddress.Text = string.Empty;
            txtCustCity.Text = string.Empty;
            txtCustEmail.Text = string.Empty;
            lblEXPdate.Text = string.Empty;

            if (RbtnY.Checked == true)
            {
                RbtnY.Checked = false;
            }
            else
            {
                RbtnN.Checked = false;
            }


        }
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["user_id"] == null)
            {
                Response.Redirect("~/Admin/AdminLoginPage.aspx");
            }
          
        }

        protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (args.Value == "")
            {
                args.IsValid = false;
            }
            else
            {
                string expression = "^[A-Za-z ]{1,20}$";
                Regex reg = new Regex(expression);
                if (reg.IsMatch(args.Value))
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;
                }
            }
        }

        protected void CustomValidAddress_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (args.Value == "")
            {
                args.IsValid = false;
            }
            else
            {
                string expression = "^[A-Za-z0-9 ]{4,200}$";
                Regex reg = new Regex(expression);
                if (reg.IsMatch(args.Value))
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;
                }
            }
        }

        protected void RbtnY_CheckedChanged(object sender, EventArgs e)
        {
            if (RbtnY.Checked == true)
            {
                Calendar_Exp.Enabled = true;
            }
        }

        protected void RbtnN_CheckedChanged(object sender, EventArgs e)
        {
            if (RbtnN.Checked == true)
            {
                Calendar_Exp.Enabled = false;
                lblEXPdate.Text = string.Empty;
            }
        
        }

        protected void Calendar_Exp_SelectionChanged(object sender, EventArgs e)
        {
            lblEXPdate.Text = DateTime.Now.ToLongDateString();

            DateTime ct = Convert.ToDateTime(lblEXPdate.Text);

            lblEXPdate.Text = Calendar_Exp.SelectedDate.ToLongDateString();

            DateTime st = Convert.ToDateTime(lblEXPdate.Text);

            if (st < ct)
            {
                lblEXPdate.Text = "Expiry Date Cannot be past date. Please select a valid date";
                txtCustCity.Enabled = false;
                txtCustEmail.Enabled = false;
                txtCust_contact.Enabled = false;
                btnCustRegister.Enabled = false;
                Response.Write("<script font color:red>alert('Please select valid expiry date')</script>");
            }
            else
            {
                lblEXPdate.Text = Calendar_Exp.SelectedDate.ToLongDateString();
                txtCustCity.Enabled = true;
                txtCustEmail.Enabled = true;
                txtCust_contact.Enabled = true;
                btnCustRegister.Enabled = true;

                if (RbtnN.Checked == true)
                {
                    Calendar_Exp.Enabled = false;
                    txtCustCity.Enabled = true;
                    txtCustEmail.Enabled = true;
                    txtCust_contact.Enabled = true;
                    btnCustRegister.Enabled = true;
                }
            }
        }

        protected void CustomValidatorCity_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (args.Value == "")
            {
                args.IsValid = false;
            }
            else
            {
                string expression = "^[A-Za-z ]{1,30}$";
                Regex reg = new Regex(expression);
                if (reg.IsMatch(args.Value))
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;
                }
            }
        }

        protected void CustomValidatorEmail_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (args.Value == "")
            {
                args.IsValid = false;
            }
            else
            {
                string expression = @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";
                Regex reg = new Regex(expression);
                if (reg.IsMatch(args.Value))
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;
                }
            }
        }

        protected void CustomValidatorContact_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (args.Value == "")
            {
                args.IsValid = false;
            }
            else
            {
                string expression = "^[0-9]{10}$";
                Regex reg = new Regex(expression);
                if (reg.IsMatch(args.Value))
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;
                }
            }
        }

        protected void btnCust_reset_Click(object sender, EventArgs e)
        {
            Reset();
        }

        protected void btnCustRegister_Click(object sender, EventArgs e)
        {
            try
            {

            if (Page.IsValid)
            {
                SqlCommand cmd;
                SqlConnection con;
                con = new SqlConnection("Data Source=LAPTOP-9DG34U7Q\\SQLEXPRESS;Initial Catalog=Event_Management_System;Integrated Security=True");
                con.Open();
                cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "SPCustomerRegistration";

                cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = txtCust_Name.Text.Trim();
                cmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = txtCustAddress.Text.Trim();

                if (RbtnN.Checked == true)
                {
                    cmd.Parameters.Add("@Membership", SqlDbType.Char).Value = 'N';
                }
                else
                {
                    cmd.Parameters.Add("@Membership", SqlDbType.Char).Value = 'Y';
                }

                if (RbtnN.Checked == true)
                {
                    DateTime ss =  new DateTime();
                    cmd.Parameters.Add("@Expiry_date", SqlDbType.Date).Value = DateTime.Today.ToString("yyyy-MM-dd");
                }
                else
                {
                    DateTime et = new DateTime();

                    et = Convert.ToDateTime(Calendar_Exp.SelectedDate.ToString("yyyy-MM-dd"));
                  //  et = Convert.ToDateTime(lblEXPdate.Text);
                    //cmd.Parameters.Add("@Expiry_date", SqlDbType.Date).Value = et.ToLongDateString();
                    cmd.Parameters.Add("@Expiry_date", SqlDbType.Date).Value = et;
                }
               

                cmd.Parameters.Add("@City", SqlDbType.VarChar).Value = txtCustCity.Text.ToUpper();
                cmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = txtCustEmail.Text.Trim();
                cmd.Parameters.Add("@Contact_no", SqlDbType.VarChar).Value = txtCust_contact.Text.Trim();
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
                Response.Write("<script>alert('Registration Successfull')</script>");
                Reset();
            }
            }
            catch (Exception s)
            {

                Response.Write("<script>alert('Please enter the valid details or the format is not supported')</script>");
            }
           
        }
        
    }
            
          
}