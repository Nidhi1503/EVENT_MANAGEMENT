﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace NewProject.Admin
{

    public partial class AdminLoginPage : System.Web.UI.Page
    {
        SqlConnection con;
        //SqlDataAdapter da;
        //SqlCommand cmd;
        //DataSet ds;
        //DataTable dt;


        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAdminLogin_Click(object sender, EventArgs e)
        {
            if (txtAdminID.Text == "" || txtAdminPwd.Text == "")
            {
                Response.Write("<script>alert('Please enter username and password and try again.')</script>");
            }
    

            string username = txtAdminID.Text;
            string password = txtAdminPwd.Text;
            con = new SqlConnection("Data Source=LAPTOP-9DG34U7Q\\SQLEXPRESS;Initial Catalog=Event_Management_System;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Admin_master WHERE admin_user_id = '" + txtAdminID.Text + "" + "' and admin_password = '" + txtAdminPwd.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            System.Data.SqlClient.SqlDataReader dr = null;
            dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                if (this.txtAdminID.Text == dr["admin_user_id"].ToString() & this.txtAdminPwd.Text == dr["admin_password"].ToString())
                {
                   Session["user_id"] = dr["admin_user_id"].ToString();


                    Response.Write("<script>alert('Login Successful')</script>");
                    Response.Redirect("~/HomePage.aspx");
                }
                else 
                { 
                    Response.Write("<script>alert('Invalid User Name / Password')</script>"); 
                }
            }
            else 
            { 
                Response.Write("<script>alert('Invalid User Name / Password')</script>"); 
            }
        }

        protected void txtReset_Click(object sender, EventArgs e)
        {
            txtAdminID.Text = string.Empty;
            txtAdminPwd.Text = string.Empty;
        }
    }
}
