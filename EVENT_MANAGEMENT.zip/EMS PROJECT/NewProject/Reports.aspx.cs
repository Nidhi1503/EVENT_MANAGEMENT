﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;

namespace NewProject
{
    public partial class Reports : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_id"] == null)
            {
                Response.Redirect("~/Admin/AdminLoginPage.aspx");
            }
        }

        //protected void Calendar2_SelectionChanged(object sender, EventArgs e)
        //{

        //}

        //protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        //{

        //}

        protected void Start_DateCalendar_SelectionChanged(object sender, EventArgs e)
        {
            LBLFinalStart.Text = Start_DateCalendar.SelectedDate.ToLongDateString();
        }

        protected void END_date_Calendar_SelectionChanged(object sender, EventArgs e)
        {


            //lblEXPdate.Text = DateTime.Now.ToLongDateString();

            //DateTime ct = Convert.ToDateTime(lblEXPdate.Text);

            //lblEXPdate.Text = Calendar_Exp.SelectedDate.ToLongDateString();
            //DateTime st = Convert.ToDateTime(lblEXPdate.Text);
            LBLFinalStart.Text = Start_DateCalendar.SelectedDate.ToLongDateString();
            LBLFinalEND.Text = END_date_Calendar.SelectedDate.ToLongDateString();
            DateTime st_date = Convert.ToDateTime(LBLFinalStart.Text);
            DateTime en_date = Convert.ToDateTime(LBLFinalEND.Text);

            if (en_date < st_date)
            {

                Response.Write("<script font color:red>alert('Please select valid date to generate Event Report')</script>");
            }

        }

        protected void btnGenerateReport_Click(object sender, EventArgs e)
        {
            try
            {

                if (LBLFinalStart.Text == "" || LBLFinalEND.Text == "")
                {
                    Response.Write("<script font color:red>alert('Please select the Start and End date to generate Event Report')</script>");

                    GridView1.Visible = false;
                    LBLGrandTotal.Visible = false;
                    LBLFinalAnswer.Visible = false;

                }
                else
                {

                    DateTime dtt = new DateTime();
                    dtt = Convert.ToDateTime(END_date_Calendar.SelectedDate.ToString("yyyy-MM-dd"));

                   // dtt = dtt.AddDays(1).ToString(); 
                 
                    LBLFinalStart.Text = Start_DateCalendar.SelectedDate.ToString("yyyy-MM-dd"); //ToLongDateString();
                    DateTime ss = dtt.AddDays(1);
                    string s = ss.ToString();
                   // LBLFinalEND.Text = dtt.AddDays(1).ToString();
                    DateTime st_date = Convert.ToDateTime(LBLFinalStart.Text);
                    DateTime en_date = Convert.ToDateTime(s);
                    //TimeSpan sp = new TimeSpan();
                    //sp = st_date - en_date;
                    //int n = Convert.ToInt32(sp.TotalHours);
                    SqlCommand cmd;
                    SqlConnection con;
                    con = new SqlConnection("Data Source=PC429615;Initial Catalog=Event_Management_System;Integrated Security=True");
                    con.Open();
                    cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "SPClculateTotalCost";
                    cmd.Parameters.Add("@Startt_date", SqlDbType.Date).Value = st_date; //ToLongDateString().Trim();
                    cmd.Parameters.Add("@End_date", SqlDbType.Date).Value = en_date; // ToLongDateString().Trim();
                    DataTable dt = new DataTable();
                    dt.Load(cmd.ExecuteReader());
                    cmd.Dispose();
                    con.Close();
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                    GridView1.Visible = true;
                    LBLGrandTotal.Visible = true;
                    LBLFinalAnswer.Visible = true;
                    int  tot_Amt=0;
                    foreach (GridViewRow grow in GridView1.Rows)
                    {
                        tot_Amt = tot_Amt + Convert.ToInt32(grow.Cells[4].Text.Trim());
                      
                    }


                    LBLFinalAnswer.Text = tot_Amt.ToString();

                }
            }
            catch (Exception q)
            {

                Response.Write("<script>alert('Please Try again later')</script>");
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}