﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NewProject
{
    public partial class AdminHomeDesign : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void LinkBtnCustomerReg_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/CustomerRegistration.aspx");
        }

        protected void btnHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/HomePage.aspx");
        }

        protected void LinkBtnEventbooking_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/EventBooking.aspx");
        }

        protected void LbtnFacilitybooking_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/FacilityBooking.aspx");
        }

        protected void LbtnVendorManagement_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/VendorManagement.aspx");
        }
      

        protected void btnLogout_Click1(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("~/Admin/AdminLoginPage.aspx");
        }

        protected void LbtnReports_Click1(object sender, EventArgs e)
        {
            Response.Redirect("~/Reports.aspx");
        }

        
    }
}