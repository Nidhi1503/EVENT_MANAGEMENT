﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;


namespace NewProject
{
    public partial class ManageAdminPage : System.Web.UI.Page
    {
        public void Reset()
        {
            txtAddPassword.Text = string.Empty;
            txtAddAdmin.Text = string.Empty;
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAddAdmin_Click(object sender, EventArgs e)
        {
            try
            {
            if (Page.IsValid)
            {

                SqlConnection con;
                SqlCommand com;
                con = new SqlConnection("Data Source=LAPTOP-9DG34U7Q\\SQLEXPRESS;Initial Catalog=Event_Management_System;Integrated Security=True;");
                con.Open();
                com = new SqlCommand("insert into Admin_Master values ('" + txtAddAdmin.Text + "','" + txtAddPassword.Text + "')", con);
                com.ExecuteNonQuery();
                con.Close();
                con.Dispose();
                Response.Redirect(Request.RawUrl); //to refresh the page automatically. 
                Reset();
            }
            }
            catch (Exception qq)
            {
                Response.Write("<script>alert('Invalid Data or format not supported')</script>");
            }     
        }

        protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (args.Value == "")
            {
                args.IsValid = false;
            }
            else
            {
                string expression = "^[a-z]{1,20}$";
                Regex reg = new Regex(expression);
                if (reg.IsMatch(args.Value))
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;
                }
            }
        }
    }
}