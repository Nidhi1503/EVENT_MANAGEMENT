﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NewProject
{
    public partial class CustomerRegistration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["user_id"] != null)
            {

                lblDate.Text = DateTime.Today.ToLongDateString();
                LBLTime.Text = DateTime.Now.ToString("HH:mm:ss tt");
                lblUser.Text = Session["user_id"].ToString();

            }
            else
            {
                Response.Redirect("~/Admin/AdminLoginPage.aspx");
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/ManageAdminPage.aspx");
        }
    }
}